# LocalGrowingFirst
Small RimWorld Mod that forces growing to target local work first

Adds two new Workgivers for local harvesting and local sowing, which have higher priorities than either normal harvest or sow. Pawns will first attempt to harvest sow in the growing zone they are on or facing before attempting other zones.

Very useful in deserts and other places with large distances between growing zones ...
